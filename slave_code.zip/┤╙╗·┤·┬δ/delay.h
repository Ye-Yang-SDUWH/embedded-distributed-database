
#ifndef	__DELAY_H
#define	__DELAY_H

#define MAIN_Fosc		11059200L	//������ʱ��
#include	"STC8.H"
	

#define  uint8    unsigned char 
#define  uint16   unsigned int 
#define  uint32   unsigned long 


void  delay_ms(unsigned int ms);

#endif
