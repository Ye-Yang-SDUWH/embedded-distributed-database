#ifndef __PCF8563_H_
#define __PCF8563_H_

#include "delay.h"

/**********************
���ű�������
***********************/			
sbit	SDA	= P2^4;	//����SDA  
sbit	SCL	= P2^5;	//����SCL


#define DIS_DOT		0x20
#define DIS_BLACK	0x10
#define DIS_		0x11

#define SLAW	0xA2
#define SLAR	0xA3

extern void I2C_init(void);
extern void I2C_Start(void);
extern void I2C_SendData(uint8 dat);
extern void I2C_RecvACK(void);
extern void I2C_SendACK(void) ;
extern void I2C_SendNAK(void);
extern uint8 I2C_RecvData(void);
extern void I2C_Stop(void);


#endif
